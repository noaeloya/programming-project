import java.util.Scanner;

public class Assignment4 {
	static Scanner sc = new Scanner(System.in);

	public static void showMenu () {//the function shows the menu

		System.out.println("0. End Program");
		System.out.println("1. Print amount of occurrences in string"); 
		System.out.println("2. Print all even numbers in array");
		System.out.println("3. Compute k mod m");
		System.out.println("4. Check if array can be divided");
		System.out.print("Enter a digit 0-4> ");
		int userchoice=sc.nextInt();
		if(userchoice==0) {//end of program
			System.out.println("See you later :)");
		}
		if (userchoice<0 || userchoice>4) {//validation check
			System.out.println("Invalid input");
	      showMenu();
		}
		if (userchoice==1) {//Print amount of occurrences in string
			System.out.print("Please enter a string> ");
			String str;
			do {
				str = sc.nextLine();
			} while (str.length() == 0);
			System.out.print("Please enter a char> ");
			char userchar=sc.next().charAt(0) ;
			System.out.println("The amount of occurrences in the string: "+occCharInString(str,userchar));
			showMenu();
		}
		if (userchoice==2) {//Print all even numbers in array
			System.out.print("Please enter the size of your array> ");
			int size=sc.nextInt();
			System.out.println("Enter the array:");
			int arr[]= new int [size]; 
			for (int i=0; i<size; i++) {
				arr[i]=sc.nextInt();
			}
			System.out.println("The amount of even numbers in the array: "+countEvenInArr(arr));
			showMenu();
		}
		if (userchoice==3) {//Compute k mod m
			System.out.println("Please enter k and m> ");
			int k=sc.nextInt();
			int m=sc.nextInt();
			System.out.println(k+" mod "+m+" = "+(mod(k,m)));
			showMenu();
		}
		if (userchoice==4) {//Check if array can be divided
			System.out.print("Please enter the size of your array> ");
			int arraysize=sc.nextInt();
			int [] userarray= new int [arraysize];
			System.out.println("Enter the array:");
			for (int i=0; i<arraysize; i++) {
				userarray[i]=sc.nextInt();
			}
				if (canDivide(userarray))
					System.out.println("This array CAN be divided.");
				else System.out.println("This array CANNOT be divided.");
			showMenu();
		}
	}
	public static int calculateSum (int [] arr, int start, int end) {//the function returns the sum of an array
		if (end==start)
			return arr[end];
		return (calculateSum(arr,start,end-1)+arr[end]);
	}

	public static boolean canDivide(int [] arr) {//the function returns if the array can be divded 
		return canDivide(arr,0,calculateSum(arr,0,arr.length-1),0);
	}
	public static boolean canDivide (int [] arr, int sumB1, int sumB2, int i) {
	if (sumB1==sumB2)
		return true;
	if (i>=arr.length)
		return false;
		return (canDivide(arr,sumB1+arr[i],sumB2-arr[i],i+1)|| canDivide(arr,sumB1,sumB2,i+1));
	}

	public static int mod(int k, int m) {// the function returns the value of k module m
		if (k<0)
			return mod(k+m,m);
		if (k<m)
			return k; 
		return mod(k-m,m);
	}

	public static int occCharInString(String str, char c) //the function returns the amount of occurrences in string
	{
		if (str == "") 
			return 0; 
		if (str.charAt(str.length()-1) == c) 
			return 1 + occCharInString(str.substring(0,str.length()-1),c);
		return occCharInString(str.substring(0,str.length()-1),c);
	}

	public static int countEvenInArr(int [] arr) {//the function counts the even numbers in the array
		return countEvenInArr(arr,0,arr.length-1);
	}

	public static int countEvenInArr(int [] arr, int start, int end) {
		if (start>end)
			return 0; 
		if (arr[end]<0)
			if((-1*arr[end])%2==0)
				return 1+ countEvenInArr(arr,start,end-1);	
		if (arr[end]%2==0)
			return 1+ countEvenInArr(arr,start,end-1);
		return countEvenInArr(arr,start,end-1);
	}
	public static void main(String[] args) {
		showMenu();
	}

}
